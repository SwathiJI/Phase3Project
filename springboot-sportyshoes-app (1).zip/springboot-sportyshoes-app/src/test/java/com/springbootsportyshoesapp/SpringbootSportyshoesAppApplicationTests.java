package com.springbootsportyshoesapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSportyshoesAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
