package com.springbootsportyshoesapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSportyshoesAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootSportyshoesAppApplication.class, args);
	}

}
